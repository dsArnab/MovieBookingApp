const mongoose = require('mongoose');

const genreSchema = new mongoose.Schema({
    genreid: { type: Number, required: true },
    genre: { type: String, required: true }
},{ 
    _id: true,
    timestamps: true
});

const Genre = mongoose.model('Genre', genreSchema);
module.exports = Genre;