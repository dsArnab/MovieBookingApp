const mongoose = require('mongoose');

// Import the models
const User = require('./user.model');
const Movie = require('./movie.model');
const Genre = require('./genre.model');
const Artist = require('./artist.model');

// Export the models
module.exports = {
  User,
  Movie,
  Genre,
  Artist
};