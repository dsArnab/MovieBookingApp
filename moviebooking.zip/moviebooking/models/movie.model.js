const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  movieid: { type: String, required: true },
  title: { type: String, required: true },
  published: { type: Boolean, required: true },
  released: { type: Boolean, required: true },
  poster_url: { type: String, required: true },
  release_date: { type: Date, required: true },
  publish_date: { type: Date, required: true },
  artists: { type: [mongoose.Schema.Types.ObjectId], ref: 'Artist', required: true },
  genres: { type: [String], required: true },
  duration: { type: Number, required: true },
  critic_rating: { type: Number, required: true },
  trailer_url: { type: String, required: true },
  wiki_url: { type: String, required: true },
  story_line: { type: String, required: true },
  shows: { type: [String], default: [] }
}, {
  _id: true,
  timestamps: true
});

const Movie = mongoose.model('Movie', movieSchema);

module.exports = Movie;
