const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const DB_URL = require('./config/db.config');

// Importing route files
const movieRoutes = require('./routes/movieRoutes');
const genreRoutes = require('./routes/genreRoutes');
const artistRoutes = require('./routes/artistRoutes');
const userRoutes = require('./routes/userRoutes');

// Initializing the app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json()); // For parsing application/json
app.use(express.json());

// Routes
app.use('/api', movieRoutes);
app.use('/api', genreRoutes);
app.use('/api', artistRoutes);
app.use('/api', userRoutes);

// MongoDB connection
mongoose
  .connect(DB_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('Connected to the MongoDB database!');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB:', err.message);
    process.exit(1); // Exit the process with an error code if connection fails
  });

// Start the server
const PORT = process.env.PORT || 8085;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});