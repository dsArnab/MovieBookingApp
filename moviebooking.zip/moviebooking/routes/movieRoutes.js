const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movie.controller');

// Get all movies
router.get('/movies', movieController.findAllMovies);

// Get movies by status (e.g., PUBLISHED or RELEASED)
router.get('/movies/status', movieController.findMoviesByStatus);

// Get a specific movie by ID
router.get('/movies/:movieId', movieController.findOne);

// Get shows for a specific movie by ID
router.get('/movies/:movieId/shows', movieController.findShows);

// Get movies by various filters (status, title, genres, artists, start_date, end_date)
router.get('/movies/filters', movieController.findMoviesByFilters);

module.exports = router;