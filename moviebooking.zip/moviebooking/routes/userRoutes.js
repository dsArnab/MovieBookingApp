const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');

// Route for user signup (POST /auth/signup)
router.post('/auth/signup', userController.signUp);

// Route for user login (POST /auth/login)
router.post('/auth/login', userController.login);

// Route for user logout (POST /auth/logout)
router.post('/auth/logout', userController.logout);

// Route for generating a coupon code (POST /auth/getCouponCode)
router.post('/auth/getCouponCode', userController.getCouponCode);

// Route for booking a show (POST /auth/bookShow)
router.post('/auth/bookShow', userController.bookShow);

module.exports = router;