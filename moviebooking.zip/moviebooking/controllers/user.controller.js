const bcrypt = require('bcrypt');
const uuidv4 = require('uuidv4');
const uuidTokenGenerator = require('uuid-token-generator');
const b2a = require('b2a');
const User = require('../models/user.model'); // Import the User model

// Helper to generate a secure access token using uuid-token-generator
const tokenGenerator = new uuidTokenGenerator(); 

// signUp - Create a new user
exports.signUp = async (req, res) => {
    const { email, first_name, last_name, contact, password } = req.body;

    try {
        // Generate username using first_name and last_name
        const username = first_name + last_name;

        // Hash the password for security
        const hashedPassword = await bcrypt.hash(password, 10);

        // Generate UUID for the user
        const userUUID = uuidv4.uuid();

        // Generate an access token for the user
        const accessToken = tokenGenerator.generate();

        // Create a new user instance
        const newUser = new User({
            email,
            first_name,
            last_name,
            username,
            contact,
            password: hashedPassword,
            role: 'user', // Default role
            isLoggedIn: false, // Default logged-in status
            uuid: userUUID,
            accesstoken: accessToken,
            coupens: [],
            bookingRequests: [],
        });

        // Save the user to the database
        const savedUser = await newUser.save();
        res.status(201).json({ message: 'User created successfully', user: savedUser });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// login - Check if the username and password match and return an access token if valid
exports.login = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Find the user by username
        const user = await User.findOne({ username });

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Compare the entered password with the hashed password in the database
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid password' });
        }

        // Generate new access token
        const newAccessToken = tokenGenerator.generate();

        // Update the user with the new access token and logged-in status
        user.accesstoken = newAccessToken;
        user.isLoggedIn = true;
        await user.save();

        // Send back the user details along with the access token
        res.status(200).json({
            message: 'Login successful',
            user: {
                username: user.username,
                uuid: user.uuid,
                accesstoken: user.accesstoken,
                isLoggedIn: user.isLoggedIn,
            },
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// logout - Logout the user by marking isLoggedIn as false and clearing the access token
exports.logout = async (req, res) => {
    const { uuid } = req.body; // Assuming the logged-in user sends their uuid

    try {
        // Find the user by UUID
        const user = await User.findOne({ uuid });

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Mark the user as logged out by setting isLoggedIn to false and clearing accesstoken
        user.isLoggedIn = false;
        user.accesstoken = '';
        await user.save();

        res.status(200).json({ message: 'Logged out successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// getCouponCode - Generate and add a coupon code for the user
exports.getCouponCode = async (req, res) => {
    const { userId } = req.body;

    try {
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Generate coupon code
        const couponCode = uuidv4.uuid();

        // Add coupon code to user's coupons array
        user.coupens.push({ couponCode });
        await user.save();

        res.status(200).json({ couponCode });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// bookShow - Book a show for the user
exports.bookShow = async (req, res) => {
    const { userId, showDetails } = req.body;

    try {
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Create a booking request
        const bookingRequest = {
            showDetails,
            bookingDate: new Date(),
        };

        // Add booking request to user's bookingRequests array
        user.bookingRequests.push(bookingRequest);
        await user.save();

        res.status(200).json({ message: 'Show booked successfully', bookingRequest });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};