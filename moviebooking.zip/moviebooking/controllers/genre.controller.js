const express = require('express');
const Genre = require('../models/genre.model'); // Import the genre model

// Fetch all genres
const findAllGenres = async (req, res) => {
  try {
    const genres = await Genre.find();
    res.status(200).json(genres);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  findAllGenres,
};