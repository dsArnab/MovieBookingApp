const express = require('express');
const Movie = require('../models/movie.model');

// Fetch all movies
const findAllMovies = async (req, res) => {
  try {
    const movies = await Movie.find(); // Retrieve all movies
    res.status(200).json(movies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Fetch movies filtered by status (e.g., 'PUBLISHED' or 'RELEASED')
const findMoviesByStatus = async (req, res) => {
  const { status } = req.query;
  const filter = {};

  if (status === 'published') {
    filter.published = true;
  } else if (status === 'released') {
    filter.released = true;
  }

  try {
    const movies = await Movie.find(filter); // Fetch filtered movies
    res.status(200).json(movies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Fetch movie details by ID
const findOne = async (req, res) => {
  const { movieId } = req.params; // Get movie ID from params

  try {
    // Find movie by movieid (custom field)
    const movie = await Movie.findOne({ movieid: movieId });
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    res.status(200).json(movie);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Fetch show details for a specific movie by ID
const findShows = async (req, res) => {
  const { movieId } = req.params; // Get movie ID from params

  try {
    const movie = await Movie.findOne({ movieid: movieId });
    if (!movie) {
      return res.status(404).json({ error: 'Movie not found' });
    }
    res.status(200).json(movie.shows); // Return shows related to the movie
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Fetch movies based on various filters (status, title, genres, artists, etc.)
const findMoviesByFilters = async (req, res) => {
  const { status, title, genres, artists, start_date, end_date } = req.query;
  const filter = {};

  if (status) {
    filter.status = status; // Filter by status (e.g., PUBLISHED or RELEASED)
  }
  if (title) {
    filter.title = { $regex: title, $options: 'i' }; // Filter by title (case-insensitive)
  }
  if (genres) {
    filter.genres = { $in: genres.split(',') }; // Filter by genres
  }
  if (artists) {
    filter.artists = { $in: artists.split(',') }; // Filter by artists
  }
  if (start_date && end_date) {
    filter.release_date = { $gte: new Date(start_date), $lte: new Date(end_date) }; // Filter by date range
  }

  try {
    const movies = await Movie.find(filter); // Fetch filtered movies
    res.status(200).json(movies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  findAllMovies,
  findMoviesByStatus,
  findOne,
  findShows,
  findMoviesByFilters,
};