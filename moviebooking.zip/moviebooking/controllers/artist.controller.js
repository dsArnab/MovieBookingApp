const express = require('express');
const Artist = require('../models/artist.model'); // Import the artist model

// Fetch all artists
const findAllArtists = async (req, res) => {
  try {
    const artists = await Artist.find();
    res.status(200).json(artists);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  findAllArtists,
};